const AWS = require('aws-sdk');
const zlib = require('zlib');
const os = require('os');
const QUEUE_URL = 'https://sqs.us-east-1.amazonaws.com/518679741595/digital-upload-event';
const SNS_ARN = "arn:aws:sns:us-east-1:518679741595:digital-upload-status";
const DB_TABLE = "digital-upload-status"
const region = {region:'us-east-1'};
const sqs = new AWS.SQS(region);
const sns = new AWS.SNS(region);
const dc = new AWS.DynamoDB.DocumentClient(region);
const s3 = new AWS.S3();

const s3Util = require('./s3-util'),
	childProcessPromise = require('./child-process-promise'),
	path = require('path'),
    MIME_TYPE = "application/pdf";

async function imageConversion(key, uploadBucket, cleanBucket){
    const resultKey = key.replace(/\.[^.]+$/, ".pdf");
    const workdir = os.tmpdir();
    const inputFile = path.join(workdir, key);
	const outputFile = path.join(workdir, 'converted-' + resultKey);
	
	return s3Util.downloadFileFromS3(uploadBucket, key, inputFile)
	.then(() => childProcessPromise.spawn(
		'/opt/bin/convert',
		[inputFile, "-resize", "1024x", "-colorspace", "Gray", outputFile],
		{env: process.env, cwd: workdir}
	))
	.then(() => s3Util.uploadFileToS3(cleanBucket, resultKey, outputFile, MIME_TYPE));
}

function getTS() {
    return ~~(Date.now() / 1000);
};

async function copyS3Object(fileName, uploadBucket, cleanBucket) {
    let params = {
        Bucket: cleanBucket,
        CopySource: uploadBucket + '/' + fileName, 
        Key: fileName 
    };
    await s3.copyObject(params, function(err, data) {
        console.log("copy S3 object");
        if (err) {
            console.log(err); 
        } else {
            console.log(data);
        }
    }).promise();
}

async function dynamoDBGet(fileName, status) {
    let params = { TableName: DB_TABLE, Key: {keyName: fileName, uploadStatus: status}};
    return new Promise((resolve, reject) => {
        dc.get(params, function(err, data) {
            if (err) { 
                console.log(err);
                return reject(err);
            }  else {
                console.log(data.Item);
                return resolve(data.Item);
            }    
        });
    });
}

async function dynamoDBUpsert(fileName, status) {
    const ts = getTS();

    let params = {
        TableName: DB_TABLE,
        Key:{
            keyName : fileName,
            uploadStatus: status
        },
        UpdateExpression: "set #updateTimestamp = :ts",
        ConditionExpression: "attribute_not_exists(keyName) OR ( keyName = :kn AND uploadStatus = :us )",
        ExpressionAttributeNames: { "#updateTimestamp": "updateTimestamp" },
        ExpressionAttributeValues:{ ":ts": ts, ":kn": fileName, ":us": status },
        ReturnValues:"UPDATED_NEW"
    };

    return new Promise((resolve, reject) => {
        dc.update(params, function(err, data) {
            if (err) { 
                console.log(err);
                return reject(err);
            }  else {
                console.log(data.Item);
                return resolve(data.Item);
            }    
        });
    });
};

async function dynamoDBPut(fileName){
    const ts = getTS();
    let params = {
        TableName: DB_TABLE,
        Item:{
          "keyName": fileName,
          "originalKeyName": fileName,
          "status": "S3URL_CREATED",
          "timestamp": ts,
          "history": [
            {
              "status": "S3URL_CREATED",
              "timestamp": ts
            }
          ],
        }
    };

    return new Promise((resolve, reject) => {
        dc.put(params, function(err, data) {
            if (err) { 
                console.log(err);
                return reject(err);
            }  else {
                console.log(data.Item);
                return resolve(data.Item);
            }    
        });
    });
}

async function sendSQS(fileName, status) {
    const msg = {keyName: fileName, status, timestamp: getTS() };
    const sqsParams = {
        MessageBody: JSON.stringify(msg),
        QueueUrl: QUEUE_URL
    };
    return new Promise((resolve, reject) => {
        let sqsdata = sqs.sendMessage(sqsParams, function(err, data) {
          if (err) {
            console.log('ERR', err);
          }
          console.log(data);
        });
    });
}

async function sendSNS(fileName, status) {
    const msg = {keyName: fileName, status, timestamp: getTS() };
    return new Promise((resolve, reject) => {
        sns.publish({
            TopicArn: SNS_ARN,
            Message: JSON.stringify(msg)
        }, function(err, data) {
            if(err) {
                console.error('error publishing to SNS', err);
                // context.fail(err);
            } else {
                console.info('message published to SNS');
                // context.succeed(null, data);
            }
        });
    });
}

function parseCloudWatchLog(event) {
    if (event.awslogs && event.awslogs.data) {
        console.log(event.awslogs.data);
        const payload = Buffer.from(event.awslogs.data, 'base64');
        const logevents = JSON.parse(zlib.unzipSync(payload).toString()).logEvents;
        const logevent = logevents[0]
        const myStr=logevent.message;
        const message = myStr.slice(myStr.indexOf("{"), myStr.length);
        const cwpData = JSON.parse(message);
        console.log(cwpData);
        return cwpData;
    }
};

module.exports = {
    imageConversion,
    getTS,
    copyS3Object,
    dynamoDBGet,
    dynamoDBUpsert,
    dynamoDBPut,
    sendSQS,
    sendSNS,
    parseCloudWatchLog
}