const AWS = require('aws-sdk');
const zlib = require('zlib');
const os = require('os');
const region = {region:'us-east-1'};
const  { copyS3Object, dynamoDBGet, dynamoDBUpsert, imageConversion, parseCloudWatchLog, sendSNS} = require('./util');
const path = require('path');
const	UPLOAD_BUCKET = process.env.UPLOAD_BUCKET,
	    CLEAN_BUCKET = process.env.CLEAN_BUCKET;

exports.handler = async (event, context) => {

    console.log(JSON.stringify(event));
    // const cwpData = parseCloudWatchLog(event);
    const cwpData=JSON.parse(event.Records[0].Sns.Message);
    const fileName = cwpData.keyName;
    // Todo: test code
    // const fileName = "IMG_0289.JPG";

    await dynamoDBUpsert(fileName,"2_SCANNED");
    if (cwpData.scanVerdict === 'Clean') {
        if (path.extname(fileName).toUpperCase() !== ".PDF") {
            await imageConversion(fileName, UPLOAD_BUCKET, CLEAN_BUCKET);
        } else {
            await copyS3Object(fileName, UPLOAD_BUCKET, CLEAN_BUCKET);   
        }
        await dynamoDBUpsert(fileName,"3_PDF_CONVERTED");
    } else {
        await dynamoDBUpsert(fileName,"7_INFECTED");
    }

    // TODO implement
    const response = {
        statusCode: 200,
        body: JSON.stringify(`file ${fileName} is processed`),
    };
    return response;

};

